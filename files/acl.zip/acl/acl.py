from os import system

#"perl bin/aclmaker.pl permit_or_deny=permit protocol=both src_addr=8-10.8.8.8 src_port=80-1000 dst_addr=10.10.10.10 dst_port=80"

kCommandTemplate = "perl Cisco-ACL-0.12/bin/aclmaker.pl permit_or_deny={permit_or_deny} protocol={protocol} src_addr={src_addr} src_port={src_port} dst_addr={dst_addr} dst_port={dst_port}"

command_dict = {}
resp = raw_input("Permit or Deny?\n>> ")
if resp.lower() == "permit":
    command_dict["permit_or_deny"] = "permit"
elif resp.lower() == "deny":
    command_dict["permit_or_deny"] = "deny"
else:
    print "Please print 'permit' or 'deny'"
    exit(-1)
command_dict["protocol"] = raw_input("Please enter the protocol or 'both'.\n>> ")
command_dict["src_addr"] = raw_input("Please enter the source ip address.\n>> ")
command_dict["src_port"] = raw_input("Please enter the source port.\n>> ")
command_dict["dst_addr"] = raw_input("Please enter the destination ip address.\n>> ")
command_dict["dst_port"] = raw_input("Please enter the destination port.\n>> ")

system(kCommandTemplate.format(**command_dict))
