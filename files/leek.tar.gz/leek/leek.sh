DELAY=.1180
mplayer Leek\ Spin-1wnE4vF9CQ4.mp3 -loop 0 2>/dev/null >/dev/null &
while [ 0 ]; do feh --bg-tile out00000.png && sleep $DELAY && feh --bg-tile out00001.png && sleep $DELAY && feh --bg-tile out00003.png && sleep $DELAY; done
