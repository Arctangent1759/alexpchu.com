import matplotlib.pyplot as plt
import numpy as np
from sys import argv
from scipy.misc import imread

def onclick(e, alignment_points):
    if e.button == 1:
        if e.xdata is not None and e.ydata is not None:
            alignment_points.append((e.xdata, e.ydata))
            plt.plot(e.xdata,e.ydata,'o')
        plt.draw()
    else:
        alignment_points.pop()
    if len(alignment_points) == 4:
        plt.close()

def GetAlignmentPoints(img):
    height, width, _ = np.shape(img)
    points = []
    fig = plt.figure()
    plt.imshow(img)
    cid1 = fig.canvas.mpl_connect('button_press_event', lambda e:onclick(e,points))
    plt.show()
    return np.array(points)

if __name__ == '__main__':
    print GetAlignmentPoints(imread(argv[1]))
