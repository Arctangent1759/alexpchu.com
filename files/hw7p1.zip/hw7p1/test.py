from panorama import *
import IPython
IPython.embed()
