import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from scipy.misc import imread, imsave
from scipy.signal import fftconvolve
import sys

def im2float(img):
    return img/255.0

def Gaussian(x, mu, sigma):
    return np.exp(-0.5*((x-mu)/sigma)**2) / (sigma*np.sqrt(2*np.pi))

def GaussianFilter(sigma):
    n = int(np.ceil(3*sigma))
    out = np.zeros((2*n+1,2*n+1))
    for i in range(-n,n+1):
        for j in range(-n,n+1):
            out[n+i][n+j] = Gaussian(i,0,sigma)*Gaussian(j,0,sigma)
    return out / np.sum(out), n

def LowPass(img, sigma):  # Applies Gaussian filter
    gaussian, n = GaussianFilter(sigma)
    return fftconvolve(img,gaussian)[n:-n,n:-n]


def blend(img1, img2, mask, n = 4, sigma = 2.0):
    _, laplacian1 = Stacks(img1, n, sigma)
    _, laplacian2 = Stacks(img2, n, sigma)
    gaussian_mask, _ = Stacks(mask, n, sigma)
    output_laplacian = []
    for i in range(n):
        l = gaussian_mask[i]*laplacian1[i]
        r = (1.0-gaussian_mask[i])*laplacian2[i]
        output_laplacian.append(l+r)
        if params['stacks']:
            fig,axes = plt.subplots(1,4)
            axes[0].imshow(gaussian_mask[i], cmap=cm.Greys_r)
            axes[1].imshow(l, cmap=cm.Greys_r)
            axes[2].imshow(r, cmap=cm.Greys_r)
            axes[3].imshow(output_laplacian[-1], cmap=cm.Greys_r)
    if params['stacks']:
        plt.show()
    return np.clip(ReconstructLaplacian(output_laplacian),0,1)

def Stacks(img,n, sigma = 1.0):
    gaussians = []
    laplacians = []
    last_gaussian = img
    for _ in range(n):
        gaussian = LowPass(img, sigma)
        laplacian = last_gaussian - gaussian
        gaussians.append(gaussian)
        laplacians.append(laplacian)
        last_gaussian = gaussian
        sigma*=2
    laplacians[-1] = gaussians[-1]
    return gaussians, laplacians

def ReconstructLaplacian(lap):
    return np.sum(lap, axis=0)

def blend_img(img1, img2, mask, n=5, sigma=1.0):
    output_r = blend(img1[:,:,0],img2[:,:,0],mask, n, sigma)
    output_g = blend(img1[:,:,1],img2[:,:,1],mask, n, sigma)
    output_b = blend(img1[:,:,2],img2[:,:,2],mask, n, sigma)
    output = np.dstack((output_r,output_g,output_b))
    return output

params = {'stacks':False}

def main():
    argv = sys.argv
    if "-o" in argv:
        outindex = argv.index("-o")
        outfile = argv[outindex+1]
        argv = argv[:outindex] + argv[outindex+2:]
    else:
        outfile = None
    if "-c" in argv:
        color = True
        argv.remove("-c")
    else:
        color = False
    if "-s" in argv:
        params['stacks'] = True
        argv.remove("-s")
    else:
        params['stacks'] = False
    img1 = im2float(imread(argv[1], not color))
    img2 = im2float(imread(argv[2], not color))
    mask = im2float(imread(argv[3], True))
    output = blend_img(img1, img2, mask, color)
    if outfile:
        imsave(outfile,output)
    else:
        if not color:
            plt.imshow(output,cmap=cm.Greys_r)
        else:
            plt.imshow(output)
        plt.show()

if __name__ == "__main__":
    main()
