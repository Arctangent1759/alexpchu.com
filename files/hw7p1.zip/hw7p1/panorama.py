import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
import IPython
from scipy.misc import imread, imsave
from align import GetAlignmentPoints
from sys import argv
from scipy.interpolate import RectBivariateSpline, interp2d
from blend import blend_img

def MakeInterp(img):
    height, width, _ = np.shape(img)
    fr=RectBivariateSpline(np.r_[:height], np.r_[:width], img[:,:,0])                                                                                                                        
    fg=RectBivariateSpline(np.r_[:height], np.r_[:width], img[:,:,1])                                                                                                                        
    fb=RectBivariateSpline(np.r_[:height], np.r_[:width], img[:,:,2])
    fa=RectBivariateSpline(np.r_[:height], np.r_[:width], img[:,:,3])
    def f(x,y):
        r=fr.ev(y,x)
        g=fg.ev(y,x)
        b=fb.ev(y,x)
        a=fa.ev(y,x)
        r[x > width] = 0.0
        r[y > height] = 0.0
        r[x < 0] = 0.0
        r[y < 0] = 0.0
        g[x > width] = 0.0
        g[y > height] = 0.0
        g[x < 0] = 0.0
        g[y < 0] = 0.0
        b[x > width] = 0.0
        b[y > height] = 0.0
        b[x < 0] = 0.0
        b[y < 0] = 0.0
        a[x > width] = 0.0
        a[y > height] = 0.0
        a[x < 0] = 0.0
        a[y < 0] = 0.0
        out = np.clip(np.dstack((r,g,b,a)),0.0,1.0)
        return out
    return f

def Homography(im1_pts, im2_pts):
    x1,y1 = im1_pts[0]
    x2,y2 = im1_pts[1]
    x3,y3 = im1_pts[2]
    x4,y4 = im1_pts[3]

    u1,v1 = im2_pts[0]
    u2,v2 = im2_pts[1]
    u3,v3 = im2_pts[2]
    u4,v4 = im2_pts[3]

    A = np.matrix([
        [x1,y1,1,0,0,0,-u1*x1,-u1*y1],
        [0,0,0,x1,y1,1,-v1*x1,-v1*y1],
        [x2,y2,1,0,0,0,-u2*x2,-u2*y2],
        [0,0,0,x2,y2,1,-v2*x2,-v2*y2],
        [x3,y3,1,0,0,0,-u3*x3,-u3*y3],
        [0,0,0,x3,y3,1,-v3*x3,-v3*y3],
        [x4,y4,1,0,0,0,-u4*x4,-u4*y4],
        [0,0,0,x4,y4,1,-v4*x4,-v4*y4],
    ])
    b = np.matrix([u1,v1,u2,v2,u3,v3,u4,v4]).T
    h = (np.linalg.inv(A)*b).T
    H = np.matrix([
        [h[0,0],h[0,1],h[0,2]],
        [h[0,3],h[0,4],h[0,5]],
        [h[0,6],h[0,7],1],
    ])
    return H

def HomogenizeCoordMatrix(m):
    m[2][m[2]==0.0]=1.0
    return m/m[2,:]

def HomogenizeCoords(v):
    return v / v[2,0]

def ToHomogenizedVector(v):
    return np.matrix([v[0],v[1],1]).T

def ToCoordMatrix(rx, ry):
    coords = np.empty((len(ry), len(rx), 3))                                                                                                                                                     
    coords[..., 0] = rx                                                                                                                                                 
    coords[..., 1] = ry[:,None]
    coords[..., 2] = 1
    return np.matrix(np.concatenate(coords)).T

def ToXYList(coord_matrix):
    tr = coord_matrix.T
    x = np.array(tr[:,0]).flatten()
    y = np.array(tr[:,1]).flatten()
    return x,y

def WarpImage(img, H):
    height, width, _ = np.shape(img)
    H_inv = np.linalg.inv(H)
    ul_x, ul_y, _ = HomogenizeCoords(H_inv*np.matrix([0,0,1]).T).flatten().tolist()[0]
    ur_x, ur_y, _ = HomogenizeCoords(H_inv*np.matrix([width,0,1]).T).flatten().tolist()[0]
    ll_x, ll_y, _ = HomogenizeCoords(H_inv*np.matrix([0,height,1]).T).flatten().tolist()[0]
    lr_x, lr_y, _ = HomogenizeCoords(H_inv*np.matrix([width,height,1]).T).flatten().tolist()[0]
    x_min = min(ul_x, ur_x, ll_x, lr_x)
    x_max = max(ul_x, ur_x, ll_x, lr_x)
    y_min = min(ul_y, ur_y, ll_y, lr_y)
    y_max = max(ul_y, ur_y, ll_y, lr_y)
    interp = MakeInterp(img)

    coords = ToCoordMatrix(np.r_[x_min:x_max-1],np.r_[y_min:y_max-1])
    x,y = ToXYList(coords)
    u,v = ToXYList(HomogenizeCoordMatrix(H*coords))
    pixels = interp(u,v)
    out = np.reshape(pixels,(y_max-y_min, x_max - x_min, 4))
    return out, (x_min, x_max, y_min, y_max)

def MultiresolutionBlend(out1, out2):
    height, width, _ = np.shape(out1)
    overlap = ((out1[:,:,3]>0).astype(int) * (out2[:,:,3]>0).astype(int))
    overlap_x = np.nonzero(overlap)[1]
    seam = (min(overlap_x) + max(overlap_x))/2
    mask = np.zeros((height,width))
    mask[:,seam:] = 1.0
    if min(np.nonzero((out1[:,:,3]>0).astype(int))[1]) < min(np.nonzero((out2[:,:,3]>0).astype(int))[1]):
        mask = 1.0-mask
    return blend_img(out1, out2, mask)

def LinearBlend(out1, out2):
    out1_data = out1[:,:,:3]
    out1_alpha = np.dstack((out1[:,:,3], out1[:,:,3], out1[:,:,3]))
    out2_data = out2[:,:,:3]
    out2_alpha = np.dstack((out2[:,:,3], out2[:,:,3], out2[:,:,3]))
    total_alpha = out1_alpha + out2_alpha
    total_alpha[total_alpha == 0.0] = 1.0
    return (out1_data*out1_alpha + out2_data*out2_alpha) / total_alpha


def CombineImages(im1, im2, bounds, blend_fn):
    im1_height, im1_width, _ = np.shape(im1)

    x_min, x_max, y_min, y_max = bounds

    im2_width = np.floor(x_max - x_min)
    im2_height = np.floor(y_max - y_min)

    left = min(x_min, 0)
    right = max(x_max, im1_width)
    top = min(y_min, 0)
    bottom = max(y_max, im1_height)

    width = np.floor(right - left)
    height = np.floor(bottom - top)

    out1 = np.zeros((height,width,4))
    out2 = np.zeros((height,width,4))

    offset_x = min(0, x_min)
    offset_y = min(0, y_min)

    out1[-offset_y + y_min:-offset_y + y_min + im2_height,-offset_x + x_min:-offset_x + x_min + im2_width] = im2
    out2[-offset_y:-offset_y + im1_height,-offset_x:-offset_x + im1_width] = im1
    return blend_fn(out1,out2)

def AddAlpha(img):
    height, width, _ = np.shape(img)
    alpha = np.ones((height, width)) * (1.0 - np.abs((np.mgrid[:height,:width][1].astype(float) - width/2)/(width/2)))
    return np.dstack((img,alpha))

if __name__ == '__main__':
    if "-o" in argv:
        index = argv.index("-o")
        outfile = argv[index+1]
        argv = argv[:index] + argv[index+2:]
    else:
        outfile = None
    im1 = imread(argv[1])/255.0
    im2 = imread(argv[2])/255.0
    im1_points = GetAlignmentPoints(im1)
    im2_points = GetAlignmentPoints(im2)
    im1 = AddAlpha(im1)
    im2 = AddAlpha(im2)
    H = Homography(im1_points, im2_points)

    im2_warped, bounds = WarpImage(im2, H)

    output = CombineImages(im1, im2_warped, bounds, MultiresolutionBlend)

    if outfile:
        imsave(outfile, output)
    else:
        plt.imshow(output)
        plt.show()

